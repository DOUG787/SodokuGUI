# SudokuGUI

Um simples jogo de Sudoku feito em Java com Swing.

## Como compilar e executar:

### Compilar:
```bash
javac src/SudokuGUI.java
```

### Executar:
```bash
java -cp src SudokuGUI
```

Requer JDK instalado (Java 8+).